import 'package:flutter/material.dart';
import 'package:Fluttergram/models_c/post.dart';
import 'package:Fluttergram/models_c/user.dart';
import 'package:Fluttergram/models_c/comment.dart';
import 'package:Fluttergram/models_c/global.dart';

class NotificationsPage extends StatefulWidget {
  @override
  _NotificationsPageState createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black,
    );
  }
}