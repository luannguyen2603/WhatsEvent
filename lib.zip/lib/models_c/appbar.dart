import 'package:flutter/material.dart';

class AppbarParams {
  List<Widget> actions;
  String title;

  AppbarParams(this.title, this.actions);
}