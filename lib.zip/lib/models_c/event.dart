import 'package:flutter/material.dart';

class Post {
  DateTime startDate;
  DateTime endDate;
  bool allDay;
  String description;
  String imageURL;
  String title;
  String location;
  bool recurring;
  String id;
}